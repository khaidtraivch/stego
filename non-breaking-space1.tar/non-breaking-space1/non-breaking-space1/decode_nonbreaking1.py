from docx import Document
import os

def decode_message_from_non_breaking_space(encoded_file, expected_bits=32):
    """Giải mã thông điệp từ file .docx sử dụng dấu cách không ngắt."""
    # Kiểm tra định dạng file
    if not encoded_file.lower().endswith('.docx'):
        print("❌ File đầu vào phải có định dạng .docx!")
        return None

    # Kiểm tra file có tồn tại không
    if not os.path.exists(encoded_file):
        print(f"❌ File {encoded_file} không tồn tại!")
        return None

    # Mở file .docx
    try:
        doc = Document(encoded_file)
    except Exception as e:
        print(f"❌ Không thể mở file .docx: {e}")
        return None

    binary_message = ""
    space_normal = '\u0020'
    space_nb = '\u00A0'
    word_count = 0

    # Duyệt qua các paragraph và run để tìm khoảng cách
    for para in doc.paragraphs:
        for run in para.runs:
            text = run.text
            i = 0
            while i < len(text) and len(binary_message) < expected_bits:
                # Tìm ký tự chữ cái/số (bắt đầu từ)
                if i < len(text) and text[i].isalnum():
                    # Tìm khoảng cách sau từ
                    j = i + 1
                    while j < len(text) and not text[j].isalnum():
                        if text[j] == space_nb:
                            binary_message += '1'  # Non-breaking space → bit 1
                            word_count += 1
                            i = j + 1
                            break
                        elif text[j] == space_normal:
                            binary_message += '0'  # Space thông thường → bit 0
                            word_count += 1
                            i = j + 1
                            break
                        j += 1
                    else:
                        i += 1
                else:
                    i += 1
            if len(binary_message) >= expected_bits:
                break
        if len(binary_message) >= expected_bits:
            break

    print(f"ℹ Số từ đã xử lý: {word_count}")
    print(f"ℹ Chuỗi nhị phân giải mã: {binary_message}")

    # Kiểm tra chuỗi nhị phân có đủ để giải mã không
    if len(binary_message) < 8 or len(binary_message) % 8 != 0:
        print("⚠ Chuỗi nhị phân không đủ hoặc không hợp lệ để giải mã thành ký tự!")
        return None

    # Chuyển nhị phân thành văn bản
    try:
        message = ""
        for i in range(0, len(binary_message), 8):
            byte = binary_message[i:i+8]
            message += chr(int(byte, 2))
        return message
    except Exception as e:
        print(f"❌ Lỗi khi giải mã chuỗi nhị phân: {e}")
        return None

# === INPUT ===
try:
    encoded_file = input("Nhập đường dẫn file .docx đã mã hóa: ").strip()
    expected_bits = int(input("Nhập số bit mong muốn (ví dụ: 32 cho 'ATTT'): ").strip())
    decoded_message = decode_message_from_non_breaking_space(encoded_file, expected_bits)
    if decoded_message:
        print("Thông điệp giải mã:", decoded_message)
except Exception as e:
    print(f"❌ Đã xảy ra lỗi: {e}")