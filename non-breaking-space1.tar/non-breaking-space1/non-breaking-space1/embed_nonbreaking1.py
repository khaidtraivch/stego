from docx import Document
import os

def text_to_binary(message):
    """Chuyển thông điệp thành chuỗi nhị phân."""
    return ''.join(format(ord(char), '08b') for char in message)

def count_words_in_docx(file_path):
    """Đếm số từ trong file .docx."""
    try:
        doc = Document(file_path)
        word_count = 0
        for para in doc.paragraphs:
            words = para.text.split()
            word_count += len(words)
        return word_count
    except Exception as e:
        raise Exception(f"Không thể đếm số từ trong file: {e}")

def embed_message_with_non_breaking_space(secret_message, cover_file, output_file):
    """Giấu thông điệp vào file .docx bằng dấu cách không ngắt."""
    if not secret_message:
        print("❌ Thông điệp bí mật không được để trống!")
        return

    binary_message = text_to_binary(secret_message)
    message_bits = len(binary_message)
    print(f"ℹ Số bit cần giấu: {message_bits}")

    if not cover_file.lower().endswith('.docx'):
        print("❌ File đầu vào phải có định dạng .docx!")
        return

    if not os.path.exists(cover_file):
        print(f"❌ File {cover_file} không tồn tại!")
        return

    try:
        word_count = count_words_in_docx(cover_file)
    except Exception as e:
        print(f"❌ Lỗi khi đọc file đầu vào: {e}")
        return
    print(f"ℹ Số từ trong file đầu vào: {word_count}")

    if word_count < message_bits:
        print(f"❌ File đầu vào không đủ từ để giấu thông điệp! Cần ít nhất {message_bits} từ, nhưng chỉ có {word_count} từ.")
        return

    try:
        doc = Document(cover_file)
    except Exception as e:
        print(f"❌ Không thể mở file .docx: {e}")
        return

    bit_index = 0
    for para in doc.paragraphs:
        if bit_index >= len(binary_message):
            break

        words = para.text.split()
        if not words:
            continue

        para.clear()
        word_index = 0
        while word_index < len(words) and bit_index < len(binary_message):
            word = words[word_index]
            new_run = para.add_run()
            new_run.add_text(word)
            if word_index < len(words) - 1:
                if binary_message[bit_index] == '0':
                    new_run.add_text('\u0020')  # Space thông thường
                else:
                    new_run.add_text('\u00A0')  # Non-breaking space
                bit_index += 1
            word_index += 1

        if word_index < len(words):
            remaining_text = ' '.join(words[word_index:])
            para.add_run(remaining_text)

    try:
        doc.save(output_file)
        print(f"✅ Đã giấu thông điệp vào file .docx: {output_file}")
    except Exception as e:
        print(f"❌ Lỗi khi lưu file đầu ra: {e}")

try:
    secret_message = input("Nhập thông điệp bí mật: ").strip()
    cover_file = input("Nhập đường dẫn file .docx phủ: ").strip()
    embed_message_with_non_breaking_space(secret_message, cover_file, 'vanban_encoded_nbspace.docx')
except Exception as e:
    print(f"❌ Đã xảy ra lỗi: {e}")