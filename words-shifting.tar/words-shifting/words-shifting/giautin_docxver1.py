from docx import Document


def text_to_binary(message):
    """Chuyển thông điệp thành chuỗi nhị phân."""
    return ''.join(format(ord(char), '08b') for char in message)


def embed_message_in_docx(secret_message, cover_file, output_file):
    # Chuyển thông điệp sang nhị phân
    binary_message = text_to_binary(secret_message)

    # Mở file .docx
    doc = Document(cover_file)

    # Biến để theo dõi vị trí bit trong thông điệp
    bit_index = 0

    # Duyệt qua tất cả các paragraph trong document
    for para in doc.paragraphs:
        if bit_index >= len(binary_message):
            break  # Đã nhúng hết thông điệp

        # Tách các từ trong paragraph
        words = para.text.split()
        if not words:
            continue

        # Xóa nội dung paragraph cũ để xây lại
        para.clear()

        # Duyệt qua từng từ
        word_index = 0
        while word_index < len(words) and bit_index < len(binary_message):
            word = words[word_index]

            # Tạo run mới cho từ này
            new_run = para.add_run()

            # Ký tự zero-width space để mã hóa bit
            zero_width_space = '\u200B'

            # Nếu bit là '0', thêm zero-width space trước từ (dịch trái)
            if binary_message[bit_index] == '0':
                new_run.add_text(zero_width_space + word)
            # Nếu bit là '1', thêm zero-width space sau từ (dịch phải)
            else:
                new_run.add_text(word + zero_width_space)

            # Thêm khoảng cách thông thường giữa các từ (trừ từ cuối cùng)
            if word_index < len(words) - 1:
                new_run.add_text(' ')

            bit_index += 1
            word_index += 1

        # Thêm lại các từ còn lại (nếu có)
        if word_index < len(words):
            remaining_text = ' '.join(words[word_index:])
            para.add_run(remaining_text)

    # Lưu file .docx mới
    doc.save(output_file)
    print(f"✅ Đã giấu thông điệp vào file .docx: {output_file}")


# === INPUT ===
secret_message = input("Nhập thông điệp bí mật: ").strip()
cover_file = input("Nhập đường dẫn file .docx phủ: ").strip()

# Thực thi giấu tin
embed_message_in_docx(secret_message, cover_file, 'vanban_encoded.docx')
