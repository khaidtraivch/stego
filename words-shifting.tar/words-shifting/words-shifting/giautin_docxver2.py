from docx import Document
import os

def text_to_binary(message):
    """Chuyển thông điệp thành chuỗi nhị phân."""
    return ''.join(format(ord(char), '08b') for char in message)

def count_words_in_docx(file_path):
    """Đếm số từ trong file .docx."""
    try:
        doc = Document(file_path)
        word_count = 0
        for para in doc.paragraphs:
            words = para.text.split()
            word_count += len(words)
        return word_count
    except Exception as e:
        raise Exception(f"Không thể đếm số từ trong file: {e}")

def embed_message_in_docx(secret_message, cover_file, output_file):
    """Giấu thông điệp vào file .docx với các điều kiện kiểm tra."""
    # Kiểm tra thông điệp có rỗng không
    if not secret_message:
        print("❌ Thông điệp bí mật không được để trống!")
        return

    # Chuyển thông điệp sang nhị phân
    binary_message = text_to_binary(secret_message)
    message_bits = len(binary_message)
    print(f"ℹ Số bit cần giấu: {message_bits}")

    # Kiểm tra định dạng file đầu vào
    if not cover_file.lower().endswith('.docx'):
        print("❌ File đầu vào phải có định dạng .docx!")
        return

    # Kiểm tra file đầu vào có tồn tại không
    if not os.path.exists(cover_file):
        print(f"❌ File {cover_file} không tồn tại!")
        return

    # Đếm số từ trong file đầu vào
    try:
        word_count = count_words_in_docx(cover_file)
    except Exception as e:
        print(f"❌ Lỗi khi đọc file đầu vào: {e}")
        return
    print(f"ℹ Số từ trong file đầu vào: {word_count}")

    # Kiểm tra số từ có đủ để giấu thông điệp không
    if word_count < message_bits:
        print(f"❌ File đầu vào không đủ từ để giấu thông điệp! Cần ít nhất {message_bits} từ, nhưng chỉ có {word_count} từ.")
        return

    # Mở file .docx
    try:
        doc = Document(cover_file)
    except Exception as e:
        print(f"❌ Không thể mở file .docx: {e}")
        return

    # Biến để theo dõi vị trí bit trong thông điệp
    bit_index = 0

    # Duyệt qua tất cả các paragraph trong document
    for para in doc.paragraphs:
        if bit_index >= len(binary_message):
            break  # Đã nhúng hết thông điệp

        # Tách các từ trong paragraph
        words = para.text.split()
        if not words:
            continue

        # Xóa nội dung paragraph cũ để xây lại
        para.clear()

        # Duyệt qua từng từ
        word_index = 0
        while word_index < len(words) and bit_index < len(binary_message):
            word = words[word_index]

            # Tạo run mới cho từ này
            new_run = para.add_run()

            # Ký tự zero-width space để mã hóa bit
            zero_width_space = '\u200B'

            # Nếu bit là '0', thêm zero-width space trước từ (dịch trái)
            if binary_message[bit_index] == '0':
                new_run.add_text(zero_width_space + word)
            # Nếu bit là '1', thêm zero-width space sau từ (dịch phải)
            else:
                new_run.add_text(word + zero_width_space)

            # Thêm khoảng cách thông thường giữa các từ (trừ từ cuối cùng)
            if word_index < len(words) - 1:
                new_run.add_text(' ')

            bit_index += 1
            word_index += 1

        # Thêm lại các từ còn lại (nếu có)
        if word_index < len(words):
            remaining_text = ' '.join(words[word_index:])
            para.add_run(remaining_text)

    # Lưu file .docx mới
    try:
        doc.save(output_file)
        print(f"✅ Đã giấu thông điệp vào file .docx: {output_file}")
    except Exception as e:
        print(f"❌ Lỗi khi lưu file đầu ra: {e}")

# === INPUT ===
try:
    secret_message = input("Nhập thông điệp bí mật: ").strip()
    cover_file = input("Nhập đường dẫn file .docx phủ: ").strip()
    # Thực thi giấu tin
    embed_message_in_docx(secret_message, cover_file, 'vanban_encoded.docx')
except Exception as e:
    print(f"❌ Đã xảy ra lỗi: {e}")
