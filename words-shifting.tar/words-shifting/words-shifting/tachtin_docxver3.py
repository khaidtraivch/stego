from docx import Document
import os

def decode_message_from_docx(encoded_file):
    """Giải mã thông điệp từ file .docx với kiểm tra và xử lý ngoại lệ."""
    # Kiểm tra định dạng file
    if not encoded_file.lower().endswith('.docx'):
        print("❌ File đầu vào phải có định dạng .docx!")
        return None

    # Kiểm tra file có tồn tại không
    if not os.path.exists(encoded_file):
        print(f"❌ File {encoded_file} không tồn tại!")
        return None

    # Mở file .docx
    try:
        doc = Document(encoded_file)
    except Exception as e:
        print(f"❌ Không thể mở file .docx: {e}")
        return None

    binary_message = ""
    zero_width_space = '\u200B'
    word_count = 0

    for para in doc.paragraphs:
        # Tách các run trong paragraph
        runs = para.runs
        for run in runs:
            text = run.text
            # Tách các từ trong run
            words = text.split()
            for word in words:
                if not word:
                    continue
                word_count += 1
                # Kiểm tra vị trí của zero-width space
                if word.startswith(zero_width_space):
                    binary_message += '0'  # Zero-width space trước từ → bit 0
                elif word.endswith(zero_width_space):
                    binary_message += '1'  # Zero-width space sau từ → bit 1

    print(f"ℹ Số từ đã xử lý: {word_count}")
    print(f"ℹ Chuỗi nhị phân giải mã: {binary_message}")

    # Kiểm tra chuỗi nhị phân có đủ để giải mã không
    if len(binary_message) < 8 or len(binary_message) % 8 != 0:
        print("⚠ Chuỗi nhị phân không đủ hoặc không hợp lệ để giải mã thành ký tự!")
        return None

    # Chuyển nhị phân thành văn bản
    message = ""
    try:
        for i in range(0, len(binary_message), 8):
            byte = binary_message[i:i+8]
            message += chr(int(byte, 2))
        return message
    except Exception as e:
        print(f"❌ Lỗi khi giải mã chuỗi nhị phân: {e}")
        return None

# === INPUT ===
try:
    encoded_file = input("Nhập đường dẫn file .docx đã mã hóa (vanban_encoded.docx): ").strip()
    decoded_message = decode_message_from_docx(encoded_file)
    if decoded_message:
        print("Thông điệp giải mã:", decoded_message)
except Exception as e:
    print(f"❌ Đã xảy ra lỗi: {e}")
