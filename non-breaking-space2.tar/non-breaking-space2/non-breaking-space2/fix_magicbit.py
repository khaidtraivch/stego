import os

def fix_magic_bit(docx_path):
    """Khôi phục magic bit của file .docx để nhận diện lại."""
    # Kiểm tra file có tồn tại không
    if not os.path.exists(docx_path):
        print(f"❌ File {docx_path} không tồn tại!")
        return

    try:
        # Đọc và sửa đổi magic bit
        with open(docx_path, 'r+b') as f:
            # Đọc 4 byte đầu tiên
            current_magic = f.read(4)
            print(f"ℹ Magic bit hiện tại: {current_magic.hex()}")

            # Di chuyển con trỏ về đầu file
            f.seek(0)
            # Khôi phục magic bit của file ZIP/.docx
            correct_magic = bytes([0x50, 0x4B, 0x03, 0x04])
            f.write(correct_magic)
            print(f"✅ Đã khôi phục magic bit thành: {correct_magic.hex()}")
            print(f"✅ File {docx_path} đã được sửa.")
    except Exception as e:
        print(f"❌ Lỗi khi khôi phục magic bit: {e}")

# === INPUT ===
try:
    docx_path = input("Nhập đường dẫn file .docx đã sửa đổi: ").strip()
    fix_magic_bit(docx_path)
except Exception as e:
    print(f"❌ Đã xảy ra lỗi: {e}")