from docx import Document
import os

def decode_message_from_non_breaking_space(encoded_file):
    """Giải mã thông điệp từ file .docx, dừng khi gặp dấu kết thúc."""
    if not encoded_file.lower().endswith('.docx'):
        print("❌ File đầu vào phải có định dạng .docx!")
        return None

    if not os.path.exists(encoded_file):
        print(f"❌ File {encoded_file} không tồn tại!")
        return None

    try:
        doc = Document(encoded_file)
    except Exception as e:
        print(f"❌ Không thể mở file .docx: {e}")
        return None

    binary_message = ""
    space_normal = '\u0020'
    space_nb = '\u00A0'
    word_count = 0
    end_marker = "11111111"

    for para in doc.paragraphs:
        for run in para.runs:
            text = run.text
            i = 0
            while i < len(text):
                if i < len(text) and text[i].isalnum():
                    j = i + 1
                    while j < len(text) and not text[j].isalnum():
                        if text[j] == space_nb:
                            binary_message += '1'
                            word_count += 1
                            i = j + 1
                            break
                        elif text[j] == space_normal:
                            binary_message += '0'
                            word_count += 1
                            i = j + 1
                            break
                        j += 1
                    else:
                        i += 1
                    # Kiểm tra dấu kết thúc
                    if len(binary_message) >= 8 and binary_message[-8:] == end_marker:
                        binary_message = binary_message[:-8]  # Loại bỏ dấu kết thúc
                        print(f"ℹ Số từ đã xử lý: {word_count}")
                        print(f"ℹ Chuỗi nhị phân giải mã: {binary_message}")
                        try:
                            message = ""
                            for k in range(0, len(binary_message), 8):
                                byte = binary_message[k:k+8]
                                message += chr(int(byte, 2))
                            return message
                        except Exception as e:
                            print(f"❌ Lỗi khi giải mã chuỗi nhị phân: {e}")
                            return None
                else:
                    i += 1

    print(f"ℹ Số từ đã xử lý: {word_count}")
    print(f"ℹ Chuỗi nhị phân giải mã: {binary_message}")
    print("⚠ Không tìm thấy dấu kết thúc hoặc chuỗi nhị phân không hợp lệ!")
    return None

try:
    encoded_file = input("Nhập đường dẫn file .docx đã mã hóa: ").strip()
    decoded_message = decode_message_from_non_breaking_space(encoded_file)
    if decoded_message:
        print("Thông điệp giải mã:", decoded_message)
except Exception as e:
    print(f"❌ Đã xảy ra lỗi: {e}")